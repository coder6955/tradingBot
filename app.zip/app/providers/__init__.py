"""External provider integrations."""
